<footer>
        <div class="footer">
            <div class="footer-content"> 
            <div class="footer-section Followus"> 
                <h4 style="color: brown;">FOLLOW US </h4>
                <div class="socials">
                    <a href="#" class="fa fa-facebook"></a>
                    <a href="#" class="fa fa-twitter"></a>
                    <a href="#" class="fa fa-google"></a>
                    <a href="#" class="fa fa-linkedin"></a>
                    <a href="#" class="fa fa-youtube"></a>
                    <a href="#" class="fa fa-instagram"></a>
                    <a href="#" class="fa fa-pinterest"></a>
                 </div>
            </div>
            <div class="footer-section1 "> 
                <br><br>
                <ul>
                    <h3 style="color: brown;">SHOP </h3>
                    <a href="#hottest"><li> New Books</li></a>
                    <a href="#searched"><li> Favorites Now</li></a>
                    <a href="#"><li> Add to cart</li></a>
                    <a href="#series"><li>Series</li></a>
                    <a href="#purchased"><li>Most purchased</li></a>
                </ul>
            </div>
            <div class="footer-section1 Information">
                <br><br>
                <ul>
                <h3 style="color: brown;">INFORMATION</h3>
                <a href="index.php"><li>Home</li></a>
                <a href="AboutUs.php"><li> About Us</li></a>
                <a href="ContactUs.php"><li> Contact Us</li></a>
                <a href="JoinUs.php"><li> Join Us</li></a>
                <a href="books.php"><li> Books</li></a>
                </ul> 
            </div>
            </div> 
            <div class="footer-bottom">
            <hr style="margin-left: 30px; margin-right: 30px;" >
            &copy; Book with us | Find your favorite books here! </div>
            </div>
    </footer>
</body>

</html>